public interface Podatak {
}