public class Laser {

    private int snaga;

    public Laser(int snaga) {
        this.snaga = snaga;
    }

    @Override
    public String toString() {
        return "Laser{snaga=" + this.snaga + "}";
    }
}