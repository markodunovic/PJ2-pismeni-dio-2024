public interface LaserStit {
}