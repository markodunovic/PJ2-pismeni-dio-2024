public abstract class Autobus extends Vozilo {
	
}