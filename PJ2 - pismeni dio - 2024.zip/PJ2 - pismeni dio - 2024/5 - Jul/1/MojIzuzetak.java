public class MojIzuzetak extends Exception {
	
	public MojIzuzetak(String msg) {
		super(msg);
	}
}