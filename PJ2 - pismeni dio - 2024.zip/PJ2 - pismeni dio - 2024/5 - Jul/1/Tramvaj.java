public abstract class Tramvaj extends Vozilo {
	
}