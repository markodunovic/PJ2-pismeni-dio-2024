public interface BaterijskoPunjenjeInterface {
	
	public void smanjiBateriju(int kolicina);
}