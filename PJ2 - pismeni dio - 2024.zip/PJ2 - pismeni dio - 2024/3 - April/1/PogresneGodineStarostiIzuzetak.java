public class PogresneGodineStarostiIzuzetak extends Exception {
	
	public PogresneGodineStarostiIzuzetak(String msg) {
		super(msg);
	}
}